package com.loginapp.Recyclers.Fragment

import android.app.AlertDialog
import android.content.DialogInterface
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.recyclerview.widget.ItemTouchHelper
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.loginapp.Cat
import com.loginapp.DB.CatsDBHelper
import com.loginapp.Recyclers.RecyclerViewAdapter
import com.loginapp.R
import com.loginapp.SwipeToDeleteCallback

class LlistatFragment(dbHelper: CatsDBHelper) : Fragment() {
    val db: CatsDBHelper =dbHelper

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        // Inflate the layout for this fragment
        val view: View = inflater.inflate(R.layout.fragment_llistat, container, false)

        // Definición de variables que se mostrarán en el layout(fragment_llistat.xml)
        val llistat: ArrayList<Cat> = db.getAllCats()
        val recyclerView:RecyclerView = view.findViewById(R.id.recyclerLlistat)
        recyclerView.layoutManager = LinearLayoutManager(context)

        val madapter = RecyclerViewAdapter(llistat, context, db)
        recyclerView.adapter = madapter

        //Creando un objeto que esta escuchando al hacer swipe para eliminar elementos criptos
        val swipeToDeleteCallback = object : SwipeToDeleteCallback(context){
            override fun onSwiped(viewHolder: RecyclerView.ViewHolder, direction: Int) {
                val position = viewHolder.adapterPosition
                val item = llistat.get(position).id;
                val confirmacion = AlertDialog.Builder(context!!)
                confirmacion.setMessage(
                    "¿Quieres eliminar a ${
                        llistat.get(position).getNom()
                    }?"
                )
                    .setPositiveButton("Si",
                        DialogInterface.OnClickListener { dialog, id ->
                            db.deleteCatById(item)
                            llistat.removeAt(position)
                            recyclerView.adapter = madapter;
                        })
                    .setNegativeButton("Cancelar",
                        DialogInterface.OnClickListener { dialog, id ->
                            Toast.makeText(context, "Cancelado", Toast.LENGTH_SHORT).show()
                            recyclerView.adapter = madapter;
                        })
                // Create the AlertDialog object and return it
                confirmacion.create().show()
                recyclerView.adapter = madapter;

            }
        }
        // Insertando a cada elemento swipe delete callback
        val itemTouchHelper = ItemTouchHelper(swipeToDeleteCallback);
        itemTouchHelper.attachToRecyclerView(recyclerView);

        return view
    }
}
