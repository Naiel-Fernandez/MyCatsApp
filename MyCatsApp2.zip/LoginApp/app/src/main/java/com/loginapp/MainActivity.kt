package com.loginapp

import android.annotation.SuppressLint
import android.content.Intent
import android.content.res.Configuration
import android.content.res.Resources
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.DisplayMetrics
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import java.util.*

@Suppress("DEPRECATION")
class MainActivity : AppCompatActivity() {
    @SuppressLint("MissingInflatedId", "SetTextI18n")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        fun setAppLocale(localeCode: String) {
            val resources: Resources = resources
            val dm: DisplayMetrics = resources.displayMetrics
            val config: Configuration = resources.configuration
            config.setLocale(Locale(localeCode.lowercase(Locale.getDefault())))

            resources.updateConfiguration(config, dm)
        }
        setContentView(R.layout.activity_main)

        // Creation of variables connected to layout 'activity_main.xml'
        val btnSignIn: Button = findViewById(R.id.btnSignIn)
        val txtUsername: EditText = findViewById(R.id.txtUsername)
        val txtPassword: EditText = findViewById(R.id.txtPassword)
        val lblLoginResult: TextView = findViewById(R.id.lblLoginResult)
        // Create the intent to change the view
        val intent = Intent(this, BottomNavigation::class.java)
        // Variables for the preferences
        val sharedPref = getSharedPreferences("mainConfig", MODE_PRIVATE)
        val editor = sharedPref.edit()

        // Check that the login have never initialized
        if (sharedPref.getBoolean("login", false)) {
            startActivity(intent)
        }

        // When we click the button we verify the inputs on login
        // If the inputs are correct that move you to the view:'fragment_home.xml'
        btnSignIn.setOnClickListener {
            // Restriction for check the name and password
            if (txtUsername.text.toString() == "admin" && txtPassword.text.toString() == "admin") {
                lblLoginResult.text = "Correct login"
                editor.putString("name", "modifyName")
                editor.putBoolean("login", true)
                editor.apply()
                startActivity(intent)
            } else {
                lblLoginResult.text = "Incorrect login"
            }
        }
    }
    public fun setAppLocale(localeCode: String) {
        val resources: Resources = resources;
        val dm: DisplayMetrics = resources.getDisplayMetrics();
        val config: Configuration = resources.getConfiguration();
        config.setLocale(Locale(localeCode.lowercase(Locale.getDefault())));
        resources.updateConfiguration(config, dm);
        startActivity(Intent(this, MainActivity::class.java));
    }
}