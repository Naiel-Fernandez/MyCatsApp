package com.loginapp.Recyclers.Fragment

import android.content.DialogInterface
import android.content.Intent
import android.content.SharedPreferences
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.fragment.app.Fragment
import com.loginapp.MainActivity
import com.loginapp.R


class SettingsFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val v: View = inflater.inflate(R.layout.fragment_settings, container, false)
        val sharedPreferences: SharedPreferences = v.context.getSharedPreferences("mainConfig",
            AppCompatActivity.MODE_PRIVATE
        )
        val deletePreferencesBtn: Button = v.findViewById(R.id.deletePreferencesBtn)
        deletePreferencesBtn.setOnClickListener{
            val confirmacion = AlertDialog.Builder(requireContext())
            confirmacion.setMessage("¿Quieres eliminar todas las preferencias guardadas?")
                .setPositiveButton("Si",
                    DialogInterface.OnClickListener { dialog, id ->
                        val editor: SharedPreferences.Editor = sharedPreferences.edit()
                        editor.clear().apply()
                        startActivity(Intent(v.context, MainActivity::class.java));
                    })
                .setNegativeButton("Cancelar",
                    DialogInterface.OnClickListener { dialog, id ->
                        Toast.makeText(context, "Cancelado", Toast.LENGTH_SHORT).show()
                    })
            confirmacion.create().show()
        }

        return v
    }

}