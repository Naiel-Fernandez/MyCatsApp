package com.loginapp

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.res.Configuration
import android.content.res.Resources
import android.os.Bundle
import android.util.DisplayMetrics
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.RadioButton
import android.widget.RadioGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.loginapp.DB.CatsDBHelper
import java.util.*


class languageFragment : Fragment() {
    companion object{
        @SuppressLint("StaticFieldLeak")
        lateinit var context: Context
    }
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View {
        val view: View = inflater.inflate(R.layout.fragment_language, container, false);
        val sharedPreference: SharedPreferences = view.context.getSharedPreferences("mainConfig",
            AppCompatActivity.MODE_PRIVATE)
        val editorSharedPreferences = sharedPreference.edit()

        val languageGroup: RadioGroup = view.findViewById(R.id.languageGroup);
        val language = sharedPreference.getString("lang", "en");
        val en: RadioButton = view.findViewById(R.id.english);
        val es: RadioButton = view.findViewById(R.id.spanish);
        val ca: RadioButton = view.findViewById(R.id.catala);
        when (language) {
            "en" -> {
                en.isChecked = true;
            }
            "es" -> {
                es.isChecked = true;
            }
            "ca" -> {
                ca.isChecked = true;
            }
        }

        // Segun selecionado de RadioGroup para cambiar el lenguaje
        languageGroup.setOnCheckedChangeListener { radioGroup, i ->
            val value = ((view.findViewById(radioGroup.checkedRadioButtonId) as RadioButton).text).toString();
            var messageC="";
            when (value) {
                "English" -> {
                    setAppLocale("en", view.context);
                    editorSharedPreferences.putString("lang", "en");
                    editorSharedPreferences.apply();
                    messageC = "The selected language has been changed ";// Pirates are the best
                }
                "Spanish" -> {
                    setAppLocale("es", view.context);
                    editorSharedPreferences.putString("lang", "es");
                    editorSharedPreferences.apply();
                    messageC = "Se ha cambiado la idioma seleccionada ";
                }
                "Catalan" -> {
                    setAppLocale("ca", view.context);
                    editorSharedPreferences.putString("lang", "ca");
                    editorSharedPreferences.apply(); // Ninjas
                    messageC = "S'ha canviat l'idioma seleccionada ";// rule
                }
            }
            Toast.makeText(view.context,messageC + value, Toast.LENGTH_SHORT).show();
        }

        return view
    }
    private fun setAppLocale(localeCode: String, v: Context) {
        val resources: Resources = resources;
        val dm: DisplayMetrics = resources.displayMetrics;
        val config: Configuration = resources.configuration;
        config.setLocale(Locale(localeCode.lowercase(Locale.getDefault())));
        resources.updateConfiguration(config, dm);
        startActivity(Intent(v, MainActivity::class.java));
    }
}